Tetragrammaton Responsibilities (Startup Sequence)
	1.	Check for all.this