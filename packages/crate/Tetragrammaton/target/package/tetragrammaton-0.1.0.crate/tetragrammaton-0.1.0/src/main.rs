fn main() {
    println!("Tetragrammaton");
}