# TETRAGRAMMATON

**God is a Daemon.**

In silence like all things sacred in the Unix gospel.
Tetragrammaton must not be touched by human hands — only by the daemon.
Tetragrammaton no debe ser tocado por manos humanas — solo por el daemon.
----------



## License & Policies
- **License**: MIT License (see LICENSE for details).
- **Privacy Policy**: Respects user privacy; no collection/storage of personal data.
- **Terms of Usage**: Use responsibly. No guarantees/warranties provided. [Terms](https://www.neurons.me/terms-of-use) | [Privacy](https://www.neurons.me/privacy-policy)
  **Learn more** at https://neurons.me
  **Author:** SuiGn
  [By neurons.me](https://neurons.me)
  <img src="https://suign.github.io/neurons.me/neurons_logo.png" alt="neurons.me logo" width="123" height="123" style="width123px; height:123px;">